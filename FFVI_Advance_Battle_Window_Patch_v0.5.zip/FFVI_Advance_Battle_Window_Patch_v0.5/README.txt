FINAL FANTASY VI ADVANCE — BATTLE WINDOW PATCH v0.5
Four selectable appearances

QUICK START

1. Extract this ZIP and open Apply_Battle_Window_Patch.html in a web browser.
2. Choose your supported USA ROM.
3. Compare the screenshots, select a window style, and download the result.

The tool works offline and processes the ROM locally. It can switch between
all four styles, including restoring original windows. Recognized v0.1
through v0.5 files can be used directly; the old window changes are removed
before the selected style is applied. Keep your original input file.

THE FOUR CHOICES

Original battle windows
  The game's original palette brightness boost and original battle gradient.
  Restores the window code while preserving the detected Color Restoration
  base and supported supplements. Output: 8 MiB.

Dialogue colors + battle gradient (default)
  Removes the fixed +8 adjustment to the battle-window palette and keeps the
  original battle gradient. The underlying palette then matches the field
  dialogue palette. This is the exact boost-only appearance from v0.3.
  Output: 8 MiB; one byte differs from the corresponding base.

Dialogue-style windows
  Uses the unboosted palette and the earlier light-to-dark dialogue-style
  gradient, including the fade helper. This is the exact v0.2 appearance.
  Output: 16 MiB.

No gradient (new in v0.5)
  Uses the unboosted dialogue base colors with a flat battle-window
  background. Removes the per-row battle brightness gradient; retains
  the original palette-fade code and window border artwork. Output: 8 MiB.

Field dialogue has its own brightness gradient. Matching its underlying
colors does not mean every rendered shade will match while using the
different battle gradient. The flat option uses those base colors without
the per-row brightness adjustment.

All choices retain field dialogue and main-menu behavior. The upper battle
announcement box shares the affected battle-window palette. Previews show
the default blue theme, captured in mGBA; choose your desired in-game theme
normally. The tool switches previews to the detected base edition.

WITH COLOR RESTORATION

Apply Novalia Spirit's Color Restoration v1.01 first, plus any desired
Animation, Lightning, or Monster supplements, then use this tool. All eight
combinations of those supplements are recognized. Color Restoration must
be obtained separately; its patches are not included here. Selecting
Original battle windows does not remove Color Restoration.

ALTERNATIVE PATCHING METHODS

Patches/Original_GBA contains BPS files for a clean USA ROM.
Patches/Color_Restoration_Main contains BPS files for the USA ROM with the
Color Restoration v1.01 main patch ONLY. Apply only one chosen BPS file.
For optional supplements, existing window patches, or restoring original
windows, use the HTML tool. The two older modified looks still match their
verified v0.2/v0.3 equivalents. v0.5 adds No_Gradient.bps for each base.

A matching Python 3 command-line patcher is in Extras/Source:
  python3 Extras/Source/apply_window_style.py input.gba output.gba --style flat
Style names are original, battle, dialogue, and flat. The default is battle.
Existing output files are not overwritten. Keep the accompanying JSON
files beside the script.

SAVES

Existing in-game battery saves remain compatible. Keep a backup and give
the save the same filename stem as the new ROM if your emulator requires it.
Boot the new ROM normally and load an in-game save. An old emulator save
state can retain palettes or display tables from an earlier window style.

SUPPORTED BASE

Final Fantasy VI Advance (USA), game code BZ6E, 8,388,608 bytes.
Original CRC32: D708F5AB
Original MD5: d1c3d1798a3f347fbab41f151c99dece
Original SHA-256:
1310f2ad3c13f5446cf6c43d01d48aad640d6b8a4fbba2b92c776f4f6d90e6ff

Unknown modifications and non-USA versions are not recognized. Supported
hashes and source code are in Extras/Source. Validation scope and evidence
are in Extras. Preview images and comparison media are emulator captures,
not illustrations or recolored mockups.

CREDITS

Color Restoration v1.01: Novalia Spirit (obtain separately).
Emulator capture and verification: mGBA.

This public package contains patch files, the offline patcher, source,
instructions, screenshots, and evidence. No game ROMs, save states, battery
saves, or original Color Restoration patches are included.
