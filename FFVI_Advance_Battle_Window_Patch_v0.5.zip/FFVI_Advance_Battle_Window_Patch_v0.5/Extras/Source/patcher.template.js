'use strict';
// All verification and patching happens locally; the generated HTML is self-contained.
const KNOWN = __KNOWN_VARIANTS__;
const SPEC = __PATCH_SPEC__;
const FLAT_SPEC = __FLAT_PATCH_SPEC__;
const PREVIEWS = __PREVIEWS__;
const SIZE = 0x800000;
const BOOST = 0x0bfea2;
const STYLES = {original:'Original battle windows', battle:'Dialogue colors + battle gradient', dialogue:'Dialogue-style windows', flat:'No gradient'};
const ORIGINAL_UPLOAD = [0x0f,0x2a,0x13,0xd0];
const ORIGINAL_INIT = [0x01,0x98,0x41,0x00,0x04,0x98,0x0a,0x18,0x15,0x80,0x05,0x98,0x09,0x18,0x0d,0x80,0x20,0x1c,0x77,0x38,0x80,0x10,0x90,0x80,0x88,0x80];

async function sha256(bytes) {
  if (!globalThis.crypto || !crypto.subtle) throw new Error('This browser cannot verify files locally. Open this page in a current version of Chrome, Edge, or Firefox.');
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(hash), value => value.toString(16).padStart(2,'0')).join('');
}

function hexBytes(hex) { return Uint8Array.from(hex.match(/../g), pair => parseInt(pair,16)); }
function sameBytes(a,b) { return a.length === b.length && a.every((value,index) => value === b[index]); }
function buildFlat(base) {
  const output = base.slice();
  for (const segment of FLAT_SPEC.segments) {
    const original = hexBytes(segment.original), patch = hexBytes(segment.data);
    if (!sameBytes(output.slice(segment.offset,segment.offset+original.length),original)) throw new Error('Unexpected instructions for the no-gradient style.');
    output.set(patch,segment.offset);
  }
  if (output.length !== FLAT_SPEC.size) throw new Error('Unexpected size for the no-gradient style.');
  return output;
}
async function recognizeFlat(input) {
  if (input.length !== FLAT_SPEC.size) return null;
  const base = input.slice(0,SIZE);
  for (const segment of FLAT_SPEC.segments) {
    const patch = hexBytes(segment.data);
    if (!sameBytes(input.slice(segment.offset,segment.offset+patch.length),patch)) return null;
    base.set(hexBytes(segment.original),segment.offset);
  }
  const digest = await sha256(base), entry = KNOWN.find(v => v.source_sha256 === digest);
  if (entry && sameBytes(buildFlat(base),input)) return {entry,base};
  return null;
}

async function patchRom(input, style) {
  if (!Object.hasOwn(STYLES,style)) throw new Error('Unknown window style.');
  if (!(input instanceof Uint8Array) || (input.byteLength !== SIZE && input.byteLength !== SIZE * 2)) throw new Error('Choose a supported 8 MiB or 16 MiB USA ROM.');
  const digest = await sha256(input);
  let entry = KNOWN.find(v => v.source_sha256 === digest);
  let previous = 'original';
  let flatBase = null;
  if (!entry) {
    entry = KNOWN.find(v => v.v01_sha256 === digest || v.v02_sha256 === digest);
    if (entry) previous = entry.v01_sha256 === digest ? 'v0.1' : 'dialogue';
  }
  if (!entry) {
    const flat = await recognizeFlat(input);
    if (flat) { entry = flat.entry; flatBase = flat.base; previous = 'flat'; }
  }
  if (!entry && input.length === SIZE && input[BOOST] === 0 && input[BOOST+1] === 0x30) {
    const reverse = input.slice(); reverse[BOOST] = 8;
    const reverseHash = await sha256(reverse);
    entry = KNOWN.find(v => v.source_sha256 === reverseHash);
    if (entry) previous = 'battle';
  }
  if (!entry) throw new Error('Unrecognized ROM. Use the supported USA game, a Color Restoration v1.01 combination, or its matching window-patched version.');
  const oldHooks = previous === 'v0.1' || previous === 'dialogue';
  if (input.length !== (oldHooks ? SIZE * 2 : SIZE)) throw new Error('Unexpected file size for this version.');
  const base = flatBase || input.slice(0,SIZE);
  if (previous !== 'original') base[BOOST] = 8;
  if (oldHooks) { base.set(ORIGINAL_UPLOAD,0x1389c0); base.set(ORIGINAL_INIT,0x146618); }
  if (await sha256(base) !== entry.source_sha256 || base[BOOST] !== 8 || base[BOOST+1] !== 0x30) throw new Error('Verification failed while restoring the original window behavior.');
  let output = new Uint8Array(style === 'dialogue' ? SPEC.size : SIZE);
  if (style === 'dialogue') output.fill(SPEC.fill);
  output.set(base);
  if (style === 'battle') output[BOOST] = 0;
  if (style === 'flat') output = buildFlat(base);
  if (style === 'dialogue') {
    for (const segment of SPEC.segments) output.set(Uint8Array.from(segment.data.match(/../g), pair => parseInt(pair,16)),segment.offset);
  }
  const outputHash = await sha256(output);
  const expected = {original:entry.source_sha256, battle:entry.target_sha256, dialogue:entry.v02_sha256, flat:entry.flat_sha256}[style];
  if (expected && outputHash !== expected) throw new Error('Output verification failed. No download was created.');
  if (style === 'battle') {
    const reverse = output.slice(); reverse[BOOST] = 8;
    if (output.length !== SIZE || output[BOOST] !== 0 || output[BOOST+1] !== 0x30 || await sha256(reverse) !== entry.source_sha256) throw new Error('Output verification failed. No download was created.');
  }
  if (style === 'flat') {
    const reverse = await recognizeFlat(output);
    if (!reverse || reverse.entry.source_sha256 !== entry.source_sha256) throw new Error('Output verification failed. No download was created.');
  }
  return {already:outputHash === digest, bytes:output, id:entry.id, label:entry.label, fromStyle:previous, style, sha256:outputHash};
}

function downloadName(name,style) {
  const stem = name.replace(/\.[^.]*$/,'').replace(/[^a-zA-Z0-9._-]+/g,'_').replace(/^\.+/,'').slice(0,90) || 'FFVI_Advance_USA';
  return stem + '_Battle_Windows_' + style + '_v0.5.gba';
}

const fileInput = document.getElementById('rom');
const downloadButton = document.getElementById('download');
const status = document.getElementById('status');
const details = document.getElementById('details');
const previewBase = document.getElementById('preview-base');
const previewNote = document.getElementById('preview-note');
const radios = Object.keys(STYLES).map(style => document.getElementById('style-'+style));
let generation = 0;
let prepared = null;

function selectedStyle() { return radios.find(radio => radio.checked).value; }
function updatePreviews() {
  const base = previewBase.value;
  for (const style of Object.keys(STYLES)) document.getElementById('preview-'+style).src = PREVIEWS[base][style];
}
async function prepare() {
  const ticket = ++generation;
  prepared = null;
  downloadButton.disabled = true;
  details.textContent = '';
  previewBase.disabled = false;
  previewNote.textContent = 'Preview colors only — the file you choose determines the game’s color palette.';
  const file = fileInput.files && fileInput.files[0];
  const style = selectedStyle();
  if (!file) { status.textContent = 'Choose a ROM to begin.'; return; }
  status.textContent = 'Checking the selected file…';
  try {
    if (file.size !== SIZE && file.size !== SIZE * 2) throw new Error('Choose a supported 8 MiB or 16 MiB USA ROM.');
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (ticket !== generation) return;
    const result = await patchRom(bytes,style);
    if (ticket !== generation) return;
    previewBase.value = result.id === 'vanilla' ? 'original' : 'restoration';
    previewBase.disabled = true;
    updatePreviews();
    previewNote.textContent = 'Previews match your selected ROM’s color palette. Screenshots use the default blue window color.';
    details.textContent = result.label + '\nSelected look: ' + STYLES[style] + '\nSHA-256: ' + result.sha256;
    if (result.already) { status.textContent = 'This ROM already uses the selected look.'; return; }
    prepared = {bytes:result.bytes, filename:downloadName(file.name,style), generation:ticket};
    status.textContent = 'Ready to download — ' + STYLES[style] + '.';
    downloadButton.disabled = false;
  } catch (error) {
    if (ticket !== generation) return;
    status.textContent = error instanceof Error ? error.message : String(error);
  }
}
fileInput.addEventListener('change',prepare);
for (const radio of radios) radio.addEventListener('change',() => { if (radio.checked) return prepare(); });
previewBase.addEventListener('change',updatePreviews);
updatePreviews();
downloadButton.addEventListener('click',() => {
  if (downloadButton.disabled || !prepared || prepared.generation !== generation) return;
  const url = URL.createObjectURL(new Blob([prepared.bytes],{type:'application/octet-stream'}));
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = prepared.filename;
  document.body.appendChild(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url),10000);
});
