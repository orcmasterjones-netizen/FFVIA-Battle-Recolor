#!/usr/bin/env python3
"""Build private flat battle-window verification ROMs from unmodified source ROMs."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'palette_sources/FFVI_Advance_Window_Comparison_ROMs_v0.2/FFVI_Advance_Window_Comparison_ROMs_v0.2'
OUT=Path(__file__).resolve().parent
SEGMENTS=[{'offset':0x1456f2,'original':'b010','data':'0020','description':'Set battle top-announcement table BLDY coefficient to zero; retain BG1 darkening mode.'},{'offset':0x0bfea2,'original':'0830','data':'0030','description':'Disable fixed +8/channel battle palette adjustment.'},{'offset':0x14662c,'original':'8010','data':'0020','description':'Set battle window table BLDY coefficient to zero; retain BG2 darkening mode and native palette fade path.'}]
SOURCES=[('original',BASE/'01_FFVI_Advance_Original_USA.gba','1310f2ad3c13f5446cf6c43d01d48aad640d6b8a4fbba2b92c776f4f6d90e6ff'),('restoration',BASE/'03_FFVI_Advance_Color_Restoration_v1.01_USA.gba','c097cd95671bce3410088ee458c567704e26d369430ab14ff550bf9db3a36dff')]
manifest={}
for name,path,expected in SOURCES:
 src=path.read_bytes();assert hashlib.sha256(src).hexdigest()==expected;assert len(src)==0x800000
 patched=bytearray(src)
 for s in SEGMENTS:
  off=s['offset'];old=bytes.fromhex(s['original']);new=bytes.fromhex(s['data'])
  assert patched[off:off+len(old)]==old
  patched[off:off+len(new)]=new
 dest=OUT/('FFVI_Advance_Flat_'+name+'_USA.gba');dest.write_bytes(patched)
 changes=[{'offset':hex(i),'before':f'{a:02x}','after':f'{b:02x}'} for i,(a,b) in enumerate(zip(src,patched)) if a!=b]
 assert len(changes)==5
 manifest[name]={'source_path':str(path),'source_sha256':expected,'target_path':str(dest),'target_sha256':hashlib.sha256(patched).hexdigest(),'size':len(patched),'changes':changes}
(OUT/'flat_patch_spec.json').write_text(json.dumps({'id':'flat','size':0x800000,'segments':SEGMENTS},indent=2)+'\n')
(OUT/'flat_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
