#!/usr/bin/env python3
"""Research replay from guard dialogue states; release captures use fresh boot."""
from pathlib import Path
import sys, json, hashlib, struct
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'boost_capture/runtime_deps/capture_runtime'))
from capture_game import CaptureGame
OUT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'palette_sources/FFVI_Advance_Window_Verification_v0.2/FFVI_Advance_Window_Verification_v0.2/gba_windows/video_audit/video/sequence.json').read_text())
MANIFEST=json.loads((OUT/'flat_manifest.json').read_text())
BOOST=ROOT/'boost_only/FFVI_Advance_Boost_Only_Test/ROMs'

def sha(x):return hashlib.sha256(x).hexdigest()
def snapshot(g):
 tables=[]
 for pointer in [0x03002fc0,0x03002fc4]:
  addr=g.read(pointer,4)
  if 0x02000000<=addr<0x02040000 or 0x03000000<=addr<0x03008000:
   rows=[{'y':y,'bldcnt':g.read(addr+y*24+16,2),'bldy':g.read(addr+y*24+20,2)} for y in range(160)]
   tables.append({'address':hex(addr),'active_window_rows':[x for x in rows if x['bldcnt'] in [0xc2,0xc4]]})
 image=np.asarray(g.capture())
 return {'frame':g.frame,'announcement_flag':g.read(0x030024bc,2),'tables':tables,'lower_x150_y126_154':np.unique(image[126:155,150],axis=0).tolist(),'upper_x10_y5_16':np.unique(image[5:17,10],axis=0).tolist(),'hardware_window_palette':bytes(g.regions[5][0x142:0x150]).hex()}

report={'method':'Replay each corresponding pre-battle guard dialogue save state through ordinary controller inputs; no guest-memory writes. Release media uses separate fresh boots.','variants':{}}
for name,meta in MANIFEST.items():
 prior='1_original' if name=='original' else '3_color_restoration'
 state=ROOT/'boost_capture/captures'/prior/'states/02_Guard_Dialogue.state'
 base=BOOST/('FFVI_Advance_Original_GBA_Boost_Only_USA.gba' if name=='original' else 'FFVI_Advance_Color_Restoration_Boost_Only_USA.gba')
 results={}
 for label,rom in [('battle',base),('flat',Path(meta['target_path']))]:
  g=CaptureGame(rom);g.load_state(state)
  black=[];frames=[];snapshots={}
  timeline=[(4,1),(350,0)]+[(row['frames'],row['keys']) for row in PLAN]
  count=0
  for n,keys in timeline:
   for _ in range(n):
    g.run(1,keys);a=np.asarray(g.capture())
    frames.append({'frame':g.frame,'middle':sha(a[24:120].tobytes()),'black':not a.any(),'fade_level':g.read(0x03007100)&15,'bg_palette_all_black':not any(g.dump(5)[:0x200])})
    if not a.any():black.append(g.frame)
    count+=1
    if count in [354,354+132,354+1246,354+1832]:
     snapshots[str(count)]=snapshot(g)
     g.capture().save(OUT/(name+'_'+label+'_'+str(count)+'.png'))
  results[label]={'black_frames':black,'frames':frames,'snapshots':snapshots,'final_image_sha256':sha(a.tobytes())}
  g.finish()
 compared=list(zip(results['battle']['frames'],results['flat']['frames']))
 summary={'same_middle_pixels_every_frame':all(a['middle']==b['middle'] for a,b in compared),'black_frames_equal':results['battle']['black_frames']==results['flat']['black_frames'],'black_frame_count':len(results['flat']['black_frames']),'fade_levels_equal':all(a['fade_level']==b['fade_level'] for a,b in compared),'final_field_image_equal':results['battle']['final_image_sha256']==results['flat']['final_image_sha256']}
 summary['stable_battle_tables_all_zero']=all(r['bldy']==0 for count,s in results['flat']['snapshots'].items() if count!='2186' for t in s['tables'] for r in t['active_window_rows'])
 summary['stable_top_interior_uniform']=results['flat']['snapshots']['486']['upper_x10_y5_16']==[[41,41,132]]
 summary['stable_lower_interior_uniform']=results['flat']['snapshots']['354']['lower_x150_y126_154']==[[41,41,132]]
 summary['observed_fade_levels']=sorted({r['fade_level'] for r in results['flat']['frames']})
 summary['passed']=all(value for value in summary.values() if isinstance(value,bool))
 for label,res in results.items():
  (OUT/(name+'_'+label+'_runtime_frames.json')).write_text(json.dumps(res['frames'])+'\n')
  del res['frames']
 report['variants'][name]={'summary':summary,**results}
 print(name,json.dumps(summary),flush=True)
(OUT/'flat_runtime_validation.json').write_text(json.dumps(report,indent=2)+'\n')
