#!/usr/bin/env python3
"""Select an FFVI Advance USA battle-window style without changing other patches."""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
KNOWN = json.loads((HERE / 'variants.json').read_text())
SPEC = json.loads((HERE / 'patch_spec.json').read_text())
FLAT_SPEC = json.loads((HERE / 'flat_patch_spec.json').read_text())
SIZE = 0x800000
BOOST = 0x0BFEA2
STYLES = {'original': 'Original battle windows', 'battle': 'Dialogue colors + battle gradient', 'dialogue': 'Dialogue-style windows', 'flat': 'No gradient'}
ORIGINAL_UPLOAD = bytes.fromhex('0f2a13d0')
ORIGINAL_INIT = bytes.fromhex('0198410004980a181580059809180d80201c7738801090808880')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def build_flat(base):
    output = bytearray(base)
    for segment in FLAT_SPEC['segments']:
        offset = segment['offset']
        original, patch = bytes.fromhex(segment['original']), bytes.fromhex(segment['data'])
        if output[offset:offset + len(original)] != original:
            raise ValueError('Unexpected instructions for the no-gradient style.')
        output[offset:offset + len(patch)] = patch
    if len(output) != FLAT_SPEC['size']:
        raise ValueError('Unexpected size for the no-gradient style.')
    return bytes(output)

def recognize_flat(data):
    if len(data) != FLAT_SPEC['size']:
        return None, None
    base = bytearray(data[:SIZE])
    for segment in FLAT_SPEC['segments']:
        offset = segment['offset']
        patch = bytes.fromhex(segment['data'])
        if data[offset:offset + len(patch)] != patch:
            return None, None
        original = bytes.fromhex(segment['original'])
        base[offset:offset + len(original)] = original
    digest = sha(base)
    entry = next((v for v in KNOWN if v['source_sha256'] == digest), None)
    if entry and build_flat(base) == data:
        return entry, base
    return None, None

def apply(data, style='battle'):
    if style not in STYLES:
        raise ValueError('Unknown style. Choose original, battle, dialogue, or flat.')
    if len(data) not in (SIZE, SIZE * 2):
        raise ValueError('Choose a supported 8 MiB or 16 MiB USA ROM.')
    digest = sha(data)
    entry = next((v for v in KNOWN if v['source_sha256'] == digest), None)
    previous = 'original'
    flat_base = None
    if entry is None:
        entry = next((v for v in KNOWN if digest in (v['v01_sha256'], v['v02_sha256'])), None)
        if entry:
            previous = 'v0.1' if digest == entry['v01_sha256'] else 'dialogue'
    if entry is None:
        entry, flat_base = recognize_flat(data)
        if entry:
            previous = 'flat'
    if entry is None and len(data) == SIZE and data[BOOST:BOOST + 2] == bytes.fromhex('0030'):
        reverse = bytearray(data)
        reverse[BOOST] = 8
        reverse_hash = sha(reverse)
        entry = next((v for v in KNOWN if v['source_sha256'] == reverse_hash), None)
        if entry:
            previous = 'battle'
    if entry is None:
        raise ValueError('Unrecognized ROM. Use a supported USA base, Color Restoration v1.01 combination, or matching window-patched ROM.')
    expected_size = SIZE * 2 if previous in ('v0.1', 'dialogue') else SIZE
    if len(data) != expected_size:
        raise ValueError('Unexpected file size for this version.')
    base = flat_base if previous == 'flat' else bytearray(data[:SIZE])
    if previous != 'original':
        base[BOOST] = 8
    if previous in ('v0.1', 'dialogue'):
        base[0x1389C0:0x1389C4] = ORIGINAL_UPLOAD
        base[0x146618:0x146632] = ORIGINAL_INIT
    if sha(base) != entry['source_sha256'] or base[BOOST:BOOST + 2] != bytes.fromhex('0830'):
        raise ValueError('Verification failed while restoring the original window behavior.')
    output = bytearray(base)
    if style == 'battle':
        output[BOOST] = 0
    elif style == 'flat':
        output = build_flat(base)
    elif style == 'dialogue':
        output.extend(bytes([SPEC['fill']]) * (SPEC['size'] - len(output)))
        for segment in SPEC['segments']:
            patch = bytes.fromhex(segment['data'])
            offset = segment['offset']
            output[offset:offset + len(patch)] = patch
    output = bytes(output)
    output_hash = sha(output)
    expected = {'original': entry['source_sha256'], 'battle': entry.get('target_sha256'), 'dialogue': entry['v02_sha256'], 'flat': entry.get('flat_sha256')}[style]
    if expected and output_hash != expected:
        raise ValueError('Output verification failed.')
    if style == 'battle':
        reverse = bytearray(output)
        reverse[BOOST] = 8
        if len(output) != SIZE or output[BOOST:BOOST + 2] != bytes.fromhex('0030') or sha(reverse) != entry['source_sha256']:
            raise ValueError('Output verification failed.')
    if style == 'flat':
        reverse_entry, reverse_base = recognize_flat(output)
        if not reverse_entry or reverse_entry['source_sha256'] != entry['source_sha256']:
            raise ValueError('Output verification failed.')
    return output, {'label': entry['label'], 'id': entry['id'], 'from_style': previous, 'style': style, 'sha256': output_hash, 'already': output_hash == digest}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--style', choices=STYLES, default='battle', help='Default: battle')
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve() or args.output.exists():
        parser.exit(1, 'Choose a new output filename; existing files are not overwritten.\n')
    try:
        output, result = apply(args.input.read_bytes(), args.style)
        if result['already']:
            print('This ROM already uses the selected look. No new file was written.')
            return
        with args.output.open('xb') as handle:
            handle.write(output)
    except (ValueError, OSError) as exc:
        parser.exit(1, str(exc) + '\n')
    print('Created:', args.output)
    print('Base:', result['label'])
    print('Style:', STYLES[args.style])
    print('SHA-256:', result['sha256'])

if __name__ == '__main__':
    main()
