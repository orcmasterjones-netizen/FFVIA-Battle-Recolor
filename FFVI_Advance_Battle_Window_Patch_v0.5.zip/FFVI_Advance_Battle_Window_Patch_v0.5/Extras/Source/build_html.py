#!/usr/bin/env python3
"""Build the self-contained offline HTML from the adjacent source and PNG previews."""
from pathlib import Path
import base64
import json

HERE = Path(__file__).resolve().parent
previews = {}
for base in ('original', 'restoration'):
    previews[base] = {}
    for style in ('original', 'battle', 'dialogue', 'flat'):
        png = (HERE / 'previews' / f'{base}_{style}.png').read_bytes()
        previews[base][style] = 'data:image/png;base64,' + base64.b64encode(png).decode()
js = (HERE / 'patcher.template.js').read_text()
for key, value in [('__KNOWN_VARIANTS__',json.loads((HERE / 'variants.json').read_text())), ('__PATCH_SPEC__',json.loads((HERE / 'patch_spec.json').read_text())), ('__FLAT_PATCH_SPEC__',json.loads((HERE / 'flat_patch_spec.json').read_text())), ('__PREVIEWS__',previews)]:
    js = js.replace(key,json.dumps(value,separators=(',',':')))
(HERE / 'patcher.js').write_text(js)
html = (HERE / 'page.template.html').read_text().replace('__SCRIPT__',js)
(HERE / 'Apply_Battle_Window_Patch.html').write_text(html)
print('Built',HERE / 'Apply_Battle_Window_Patch.html')
