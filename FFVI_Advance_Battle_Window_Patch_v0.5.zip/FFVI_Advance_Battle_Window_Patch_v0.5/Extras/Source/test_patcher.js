// Tests the exact inline HTML JavaScript using real ROM bytes and a DOM/File/Blob harness.
const fs=require('fs'), path=require('path'), vm=require('vm'), crypto=require('crypto'), assert=require('assert');
const HERE=__dirname, WORK=path.resolve(HERE,'../..');
const BASE=path.join(WORK,'palette_sources/FFVI_Advance_Window_Comparison_ROMs_v0.2/FFVI_Advance_Window_Comparison_ROMs_v0.2');
const html=fs.readFileSync(path.join(HERE,'Apply_Battle_Window_Patch.html'),'utf8');
const script=html.match(/<script>\s*([\s\S]*?)\s*<\/script>/)[1];
const known=JSON.parse(fs.readFileSync(path.join(HERE,'variants.json'),'utf8'));
const spec=JSON.parse(fs.readFileSync(path.join(HERE,'patch_spec.json'),'utf8'));
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const styles=['original','battle','dialogue','flat'];
assert(!/<script[^>]+src=|<link[^>]+href=|fetch\(|XMLHttpRequest/.test(html));
function fixture(base,id){
  const out=Buffer.alloc(0x1000000,255);base.copy(out);out[0xbfea2]=0;
  Buffer.from('01480bf019fe08e001008008'+'c046'.repeat(7),'hex').copy(out,0x146618);
  const hook=spec.segments.find(s=>s.offset===0x800000);Buffer.from(hook.data,'hex').copy(out,hook.offset);
  assert.strictEqual(digest(out),known.find(v=>v.id===id).v01_sha256);return out;
}
const originals={vanilla:fs.readFileSync(path.join(BASE,'01_FFVI_Advance_Original_USA.gba')),restoration:fs.readFileSync(path.join(BASE,'03_FFVI_Advance_Color_Restoration_v1.01_USA.gba'))};
const sources=[];
for(const [id,base] of Object.entries(originals)){
  const battle=Buffer.from(base);battle[0xbfea2]=0;
  const dialogue=fs.readFileSync(path.join(BASE,id==='vanilla'?'02_FFVI_Advance_Window_Shading_v0.2_USA.gba':'04_FFVI_Advance_Color_Restoration_Window_Shading_v0.2_USA.gba'));
  const flat=fs.readFileSync(path.join(WORK,'no_gradient/core/FFVI_Advance_Flat_'+(id==='vanilla'?'original':'restoration')+'_USA.gba'));
  sources.push([id,'original',base],[id,'v0.1',fixture(base,id)],[id,'battle',battle],[id,'dialogue',dialogue],[id,'flat',flat]);
}
function element(){return {disabled:false,textContent:'',files:[],value:'',checked:false,src:'',handlers:{},addEventListener(e,f){this.handlers[e]=f;}};}
function harness(){
  const e={};for(const id of ['rom','download','status','details','preview-base','preview-note',...styles.map(s=>'style-'+s),...styles.map(s=>'preview-'+s)])e[id]=element();
  e.download.disabled=true;e['preview-base'].value='original';for(const s of styles){e['style-'+s].value=s;e['style-'+s].checked=s==='battle';}
  const urls=new Map(),downloads=[];let count=0;
  const c={Uint8Array,ArrayBuffer,Blob,Error,console,crypto:crypto.webcrypto,setTimeout(fn){fn();},URL:{createObjectURL(blob){const u='blob:test-'+(++count);urls.set(u,blob);return u;},revokeObjectURL(u){urls.delete(u);}},document:{getElementById(id){assert(e[id],id);return e[id];},body:{appendChild(){}},createElement(tag){assert.strictEqual(tag,'a');return {click(){downloads.push({blob:urls.get(this.href),name:this.download});},remove(){}};}}};
  vm.createContext(c);vm.runInContext(script,c);
  function file(b,name='input.gba',custom){return {name,size:b.length,arrayBuffer:custom||(()=>Promise.resolve(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)))};}
  async function select(f){e.rom.files=f?[f]:[];await e.rom.handlers.change();}
  async function style(s){for(const v of styles)e['style-'+v].checked=v===s;await e['style-'+s].handlers.change();}
  return {c,e,downloads,file,select,style,click(){e.download.handlers.click();}};
}
const target=(id,style)=>{const v=known.find(v=>v.id===id);return {original:v.source_sha256,battle:v.target_sha256,dialogue:v.v02_sha256,flat:v.flat_sha256}[style];};
async function main(){
  const cases=[];
  for(const [id,from,data] of sources)for(const style of styles){
    const h=harness();await h.style(style);const before=digest(data);await h.select(h.file(data,id+'_'+from+'.gba'));h.click();
    const already=from===style;
    assert.strictEqual(h.e.download.disabled,already,id+' '+from+'→'+style);
    assert.strictEqual(h.e['preview-base'].value,id==='vanilla'?'original':'restoration');
    assert(h.e['preview-base'].disabled);assert(h.e['preview-'+style].src.startsWith('data:image/png;base64,'));
    if(already){assert(h.e.status.textContent.includes('already'));assert.strictEqual(h.downloads.length,0);}
    else{assert.strictEqual(h.downloads.length,1);const result=Buffer.from(await h.downloads[0].blob.arrayBuffer());assert.strictEqual(digest(result),target(id,style));assert(h.downloads[0].name.endsWith('_Battle_Windows_'+style+'_v0.5.gba'));}
    assert.strictEqual(digest(data),before);cases.push({case:id+' '+from+' → '+style,result:'pass',already});
  }
  const original=originals.vanilla, restored=originals.restoration, corrupt=Buffer.from(original);corrupt[200]^=1;
  for(const [name,data] of [['bad size',Buffer.alloc(9)],['modified base',corrupt],['unknown 16 MiB',Buffer.alloc(0x1000000)]]){
    const h=harness();await h.select(h.file(original));await h.select(h.file(data));h.click();assert(h.e.download.disabled);assert(!h.downloads.length);cases.push({case:name+' clears prepared output',result:'pass'});
  }
  {
    const h=harness();await h.select(h.file(original));await h.select(null);h.click();assert(h.e.download.disabled);assert(!h.downloads.length);cases.push({case:'clear selection invalidates download',result:'pass'});
  }
  {
    const h=harness();let resolve;const delayed=new Promise(r=>resolve=r);
    const pending=h.select(h.file(original,'old.gba',()=>delayed));await h.select(h.file(restored,'new.gba'));
    resolve(original.buffer.slice(original.byteOffset,original.byteOffset+original.byteLength));await pending;h.click();
    assert.strictEqual(digest(Buffer.from(await h.downloads[0].blob.arrayBuffer())),target('restoration','battle'));assert(h.downloads[0].name.startsWith('new_'));
    cases.push({case:'late previous file cannot replace latest selection',result:'pass'});
  }
  {
    const h=harness();let resolve,read=0;const delayed=new Promise(r=>resolve=r),buffer=original.buffer.slice(original.byteOffset,original.byteOffset+original.byteLength);
    const pending=h.select(h.file(original,'style_race.gba',()=>++read===1?delayed:Promise.resolve(buffer)));
    await h.style('dialogue');resolve(buffer);await pending;h.click();
    assert.strictEqual(digest(Buffer.from(await h.downloads[0].blob.arrayBuffer())),target('vanilla','dialogue'));assert(h.downloads[0].name.endsWith('_dialogue_v0.5.gba'));
    cases.push({case:'late previous style cannot replace latest selection',result:'pass'});
  }
  {
    const h=harness();await h.select(h.file(original));const pending=h.style('dialogue');h.click();assert(!h.downloads.length);await pending;h.click();
    assert.strictEqual(digest(Buffer.from(await h.downloads[0].blob.arrayBuffer())),target('vanilla','dialogue'));cases.push({case:'style change immediately invalidates old prepared output',result:'pass'});
  }
  {
    const h=harness();h.c.crypto=undefined;await h.select(h.file(original));h.click();assert(h.e.status.textContent.includes('cannot verify'));assert(!h.downloads.length);cases.push({case:'missing SHA-256 fails closed',result:'pass'});
  }
  for(const style of ['battle','dialogue','flat']){
    const h=harness();vm.runInContext("KNOWN.find(v=>v.id==='vanilla')."+({battle:'target_sha256',dialogue:'v02_sha256',flat:'flat_sha256'}[style])+"='"+'0'.repeat(64)+"'",h.c);
    await h.style(style);await h.select(h.file(original));h.click();assert(h.e.status.textContent.includes('Output verification failed'));assert(!h.downloads.length);cases.push({case:style+' output hash mismatch fails closed',result:'pass'});
  }
  {
    const h=harness(),data=Buffer.from(sources.find(([id,style])=>id==='vanilla'&&style==='flat')[2]);data[200]^=1;
    await h.style('original');await h.select(h.file(data));h.click();assert(h.e.download.disabled);assert(!h.downloads.length);assert(h.e.status.textContent.includes('Unrecognized'));
    cases.push({case:'modified flat ROM fails full base verification',result:'pass'});
  }
  {
    const h=harness();let resolve,read=0;const delayed=new Promise(r=>resolve=r),buffer=original.buffer.slice(original.byteOffset,original.byteOffset+original.byteLength);
    const pending=h.select(h.file(original,'flat_race.gba',()=>++read===1?delayed:Promise.resolve(buffer)));
    await h.style('flat');resolve(buffer);await pending;h.click();
    assert.strictEqual(digest(Buffer.from(await h.downloads[0].blob.arrayBuffer())),target('vanilla','flat'));assert(h.downloads[0].name.endsWith('_flat_v0.5.gba'));
    cases.push({case:'flat selection wins over previous pending style',result:'pass'});
  }
  {
    const h=harness(),before=h.e['preview-battle'].src;h.e['preview-base'].value='restoration';await h.e['preview-base'].handlers.change();assert.notStrictEqual(before,h.e['preview-battle'].src);assert(h.e.download.disabled);cases.push({case:'preview palette toggle changes only previews',result:'pass'});
  }
  const report={result:'pass',method:'Exact inline HTML script in Node vm with DOM/File/Blob/download harness. Not a real-browser UI test.',registered_variants:known.length,exercised_variants:['Original USA','Color Restoration main only'],historical_fixtures:'v0.1 reconstructed and full-ROM SHA-256 verified before use; all fixtures remained in memory.',cases};
  fs.writeFileSync(path.join(HERE,'html_validation.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({result:report.result,cases:cases.length}));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
