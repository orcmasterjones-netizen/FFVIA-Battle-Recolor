#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
BASE = WORK / 'palette_sources/FFVI_Advance_Window_Comparison_ROMs_v0.2/FFVI_Advance_Window_Comparison_ROMs_v0.2'
spec = importlib.util.spec_from_file_location('patcher', HERE / 'apply_window_style.py')
patcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(patcher)
cases = []
originals = {}
for ident, base_file, dialogue_file in [('vanilla','01_FFVI_Advance_Original_USA.gba','02_FFVI_Advance_Window_Shading_v0.2_USA.gba'),('restoration','03_FFVI_Advance_Color_Restoration_v1.01_USA.gba','04_FFVI_Advance_Color_Restoration_Window_Shading_v0.2_USA.gba')]:
    base = (BASE / base_file).read_bytes()
    originals[ident] = base
    entry = next(v for v in patcher.KNOWN if v['id'] == ident)
    battle = bytearray(base)
    battle[patcher.BOOST] = 0
    old = bytearray(base) + bytearray([255]) * patcher.SIZE
    old[patcher.BOOST] = 0
    old[0x146618:0x146632] = bytes.fromhex('01480bf019fe08e001008008'+'c046'*7)
    hook = next(s for s in patcher.SPEC['segments'] if s['offset'] == patcher.SIZE)
    old[hook['offset']:hook['offset']+len(bytes.fromhex(hook['data']))] = bytes.fromhex(hook['data'])
    assert patcher.sha(old) == entry['v01_sha256']
    flat = (WORK / 'no_gradient/core' / f'FFVI_Advance_Flat_{"original" if ident == "vanilla" else "restoration"}_USA.gba').read_bytes()
    sources = {'original':base,'battle':bytes(battle),'dialogue':(BASE / dialogue_file).read_bytes(),'v0.1':bytes(old),'flat':flat}
    for previous, data in sources.items():
        before = patcher.sha(data)
        for style in patcher.STYLES:
            out, result = patcher.apply(data,style)
            expected = {'original':entry['source_sha256'],'battle':entry['target_sha256'],'dialogue':entry['v02_sha256'],'flat':entry['flat_sha256']}[style]
            assert patcher.sha(out) == expected
            assert result['already'] == (previous == style)
            assert patcher.sha(data) == before
            cases.append({'case':f'{ident} {previous} → {style}','result':'pass'})
bad = bytearray(originals['vanilla'])
bad[200] ^= 1
for label,data,style in [('bad size',b'bad','battle'),('modified base',bad,'battle'),('unknown style',originals['vanilla'],'unknown'),('unknown 16 MiB',bytes(patcher.SIZE*2),'dialogue')]:
    try: patcher.apply(data,style)
    except ValueError: cases.append({'case':label,'result':'rejected correctly'})
    else: raise AssertionError(label)
with tempfile.TemporaryDirectory() as d:
    folder = Path(d)
    source, output = folder/'source.gba', folder/'output.gba'
    source.write_bytes(originals['vanilla'])
    command = [sys.executable,str(HERE/'apply_window_style.py'),str(source),str(output)]
    run = subprocess.run(command,capture_output=True,text=True)
    assert run.returncode == 0, run.stderr
    assert patcher.sha(output.read_bytes()) == patcher.KNOWN[0]['target_sha256']
    cases.append({'case':'CLI default creates battle style','result':'pass'})
    before = output.read_bytes()
    run = subprocess.run(command+['--style','dialogue'],capture_output=True,text=True)
    assert run.returncode != 0 and output.read_bytes() == before
    cases.append({'case':'CLI refuses existing output without changing it','result':'pass'})
    run = subprocess.run([sys.executable,str(HERE/'apply_window_style.py'),str(source),str(source)],capture_output=True,text=True)
    assert run.returncode != 0 and source.read_bytes() == originals['vanilla']
    cases.append({'case':'CLI refuses input overwrite','result':'pass'})
    same = folder/'same.gba'
    run = subprocess.run([sys.executable,str(HERE/'apply_window_style.py'),str(source),str(same),'--style','original'],capture_output=True,text=True)
    assert run.returncode == 0 and not same.exists() and 'already' in run.stdout
    cases.append({'case':'CLI same look creates no redundant file','result':'pass'})
    flat_output = folder/'flat.gba'
    run = subprocess.run([sys.executable,str(HERE/'apply_window_style.py'),str(source),str(flat_output),'--style','flat'],capture_output=True,text=True)
    assert run.returncode == 0 and patcher.sha(flat_output.read_bytes()) == patcher.KNOWN[0]['flat_sha256'], run.stderr
    cases.append({'case':'CLI creates flat style','result':'pass'})
    restored_output = folder/'restored.gba'
    run = subprocess.run([sys.executable,str(HERE/'apply_window_style.py'),str(flat_output),str(restored_output),'--style','original'],capture_output=True,text=True)
    assert run.returncode == 0 and restored_output.read_bytes() == originals['vanilla'], run.stderr
    cases.append({'case':'CLI reverts flat style to exact original','result':'pass'})
report = {'result':'pass','registered_variants':len(patcher.KNOWN),'exercised_variants':['Original USA','Color Restoration main only'],'cases':cases}
(HERE/'python_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':'pass','cases':len(cases)}))
