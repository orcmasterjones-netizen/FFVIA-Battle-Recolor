Gameplay timing was tested with mGBA's software renderer. Each build booted
from reset and followed the same recorded inputs into Narshe. The baseline
was its matching native battle gradient with the fixed palette boost removed.

The first replay covers 2,366 frames from the guard dialogue through commands,
Fire Beam, victory, both fades and the return to the field. The next 5,444
frames include two further encounters and both returns to the field. All
7,810 frames matched in the upper 120 visible rows on each of the four bases.
The comparison excludes the lower 40 rows that carry the requested gradient.
A second test applied the packaged SNES-style BPS to each base and compared
it directly with that base using its original boosted windows. Each replay
started at the Narshe guard dialogue, frame 22,858 for both builds. Across
all 7,810 frames, battlefield rows 32 through 119, fade levels and the
battle display's active intervals matched in all three encounters. The full
final field image also matched for each pair. Raw intervals and corresponding
ROM hashes are in original-window-timing.json. The top banner uses unboosted
colors.

Frame intervals in gameplay-timing.json start at zero and include both ends.
The later encounters use their own frame zero immediately after the opening
replay. Native checksums cover all 18 USA and European base profiles. All 16
BPS patches generated the expected ROM bytes. Both the Python patcher and
the distributed HTML passed 630 upgrade, style-switch and restore paths.
Supplement combinations were verified at the ROM level.

The scanline test sampled 2,000 horizontal interrupts per build at a stable
battle display. Both original and v0.8 handlers took 57 CPU cycles on visible
rows and 50 on vertical-blank rows, measured from dispatch entry to BIOS
return. At vertical blank, the native A7 palette value matched on every
frame of the opening replay. A separate same-state test compared the default
fill at x=150 on every lower scanline with v0.7, including fades. A custom
fill matched the v0.6 shading at the same coordinates. The SNES comparison
uses the player's scaled screenshot and unfiltered emulator captures.
Verification covers the opening Narshe sequence in emulation.
