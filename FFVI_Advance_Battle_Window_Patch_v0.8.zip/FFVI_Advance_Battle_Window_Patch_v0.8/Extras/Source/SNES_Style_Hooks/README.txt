The battle-window initializer installs the alternate interrupt instructions
when it finishes the lower window tables. The battle-display cleanup restores
both original instruction ranges under the saved interrupt master-enable
setting. The original handler remains in place during the opening and field.
The install and restore routines leave the original callback table in place.

The palette transfer uses the native game code. The fade hook selects a
precomputed RGB555 row from the unfaded default blue or its native faded
palette buffer. A custom fill color bypasses the additional writes. The
horizontal blank handler writes palette entry A7 for the lower window and
restores the default fill for the next frame. The upper banner uses the
game's normal palette. The raster timing was measured in mGBA.

The regional listings use execution addresses, including the IWRAM address
of the handler. regions.json holds the complete emitted patch, precomputed
colors, and original bytes for restoration. The USA expansion starts at
0x08800000. The European build uses padding starting at 0x08C00000.
