#!/usr/bin/env python3
"""Select an FFVI Advance USA or European battle-window style without changing other patches."""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
PROFILES = json.loads((HERE / 'profiles.json').read_text())
REGIONS = json.loads((HERE / 'regions.json').read_text())
STYLES = {'original': 'Original battle windows', 'battle': 'Dialogue colors + battle gradient', 'dialogue': 'Dialogue-style windows', 'flat': 'No gradient', 'snes': 'SNES-style blue range'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def apply(data, style='battle'):
    if style not in STYLES:
        raise ValueError('Unknown window style.')
    if len(data) not in (0x800000, 0x1000000):
        raise ValueError('Choose a supported 8 MiB or 16 MiB USA or European ROM.')
    digest = sha(data)
    for profile in PROFILES:
        previous = next((s for s, h in profile['hashes'].items() if h == digest), None)
        if previous is not None:
            break
    else:
        raise ValueError('Unrecognized ROM. Choose a supported USA or European base or Color Restoration v1.01 combination.')
    region = REGIONS[profile['region']]
    base = bytearray(data[:region['size']])
    for change in region['styles'][previous]:
        if change['before']:
            before = bytes.fromhex(change['before'])
            offset = change['offset']
            base[offset:offset + len(before)] = before
    if sha(base) != profile['hashes']['original']:
        raise ValueError('Base verification failed.')
    edits = region['styles'][style]
    if any(c['offset'] >= len(base) for c in edits):
        base.extend(b'\xff' * (0x1000000 - len(base)))
    for change in edits:
        offset = change['offset']
        patch = bytes.fromhex(change['data'])
        base[offset:offset + len(patch)] = patch
    output_hash = sha(base)
    if output_hash != profile['hashes'][style]:
        raise ValueError('Output verification failed.')
    return bytes(base), {'id': profile['id'], 'label': profile['label'], 'already': digest == output_hash, 'sha256': output_hash}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--style', choices=STYLES, default='battle', help='Default: battle')
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve() or args.output.exists():
        parser.exit(1, 'Choose a new output filename; existing files are not overwritten.\n')
    try:
        output, result = apply(args.input.read_bytes(), args.style)
        if result['already']:
            print('This ROM already uses the selected look. No new file was written.')
            return
        with args.output.open('xb') as handle:
            handle.write(output)
    except (ValueError, OSError) as exc:
        parser.exit(1, str(exc) + '\n')
    print('Created:', args.output)
    print('Base:', result['label'])
    print('Style:', STYLES[args.style])
    print('SHA-256:', result['sha256'])

if __name__ == '__main__':
    main()
