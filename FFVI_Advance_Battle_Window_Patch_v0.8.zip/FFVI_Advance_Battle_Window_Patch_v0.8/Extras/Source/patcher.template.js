'use strict';
const PROFILES = __PROFILES__;
const REGIONS = __REGIONS__;
const PREVIEWS = __PREVIEWS__;
const STYLES = {original:'Original battle windows', battle:'Dialogue colors + battle gradient', dialogue:'Dialogue-style windows', flat:'No gradient', snes:'SNES-style blue range'};
async function sha256(bytes) {
  if (!globalThis.crypto || !crypto.subtle) throw new Error('This browser cannot verify files locally. Open this page in a current version of Chrome, Edge, or Firefox.');
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(hash), value => value.toString(16).padStart(2,'0')).join('');
}

function hexBytes(hex) { return Uint8Array.from(hex.match(/../g), pair => parseInt(pair,16)); }

async function patchRom(input, style) {
  if (!Object.hasOwn(STYLES, style)) throw new Error('Unknown window style.');
  const digest = await sha256(input);
  const profile = PROFILES.find(entry => Object.values(entry.hashes).includes(digest));
  if (!profile) throw new Error('Unrecognized ROM. Choose a supported USA or European game or Color Restoration v1.01 combination.');
  const previous = Object.keys(profile.hashes).find(key => profile.hashes[key] === digest);
  const region = REGIONS[profile.region];
  const base = input.slice(0, region.size);
  for (const change of region.styles[previous]) {
    if (change.before) base.set(hexBytes(change.before), change.offset);
  }
  if (await sha256(base) !== profile.hashes.original) throw new Error('Base verification failed.');
  const edits = region.styles[style];
  const expanded = edits.some(change => change.offset >= base.length);
  const output = new Uint8Array(expanded ? 0x1000000 : base.length);
  if (expanded) output.fill(255);
  output.set(base);
  for (const change of edits) output.set(hexBytes(change.data), change.offset);
  const outputHash = await sha256(output);
  if (outputHash !== profile.hashes[style]) throw new Error('Output verification failed.');
  return {already: digest === outputHash, bytes:output, label:profile.label, preview:profile.preview, sha256:outputHash};
}
function downloadName(name,style) {
  const stem = name.replace(/\.[^.]*$/,'').replace(/[^a-zA-Z0-9._-]+/g,'_').replace(/^\.+/,'').slice(0,90) || 'FFVI_Advance_USA';
  return stem + '_Battle_Windows_' + style + '_v0.8.gba';
}

const fileInput = document.getElementById('rom');
const downloadButton = document.getElementById('download');
const status = document.getElementById('status');
const details = document.getElementById('details');
const previewBase = document.getElementById('preview-base');
const previewNote = document.getElementById('preview-note');
const radios = Object.keys(STYLES).map(style => document.getElementById('style-'+style));
let generation = 0;
let prepared = null;

function selectedStyle() { return radios.find(radio => radio.checked).value; }
function updatePreviews() {
  const base = previewBase.value;
  for (const style of Object.keys(STYLES)) document.getElementById('preview-'+style).src = PREVIEWS[base][style];
}
async function prepare() {
  const ticket = ++generation;
  prepared = null;
  downloadButton.disabled = true;
  details.textContent = '';
  previewBase.disabled = false;
  previewNote.textContent = 'Preview colors only — the file you choose determines the game’s color palette.';
  const file = fileInput.files && fileInput.files[0];
  const style = selectedStyle();
  if (!file) { status.textContent = 'Choose a ROM to begin.'; return; }
  status.textContent = 'Checking the selected file…';
  try {
    if (file.size !== 0x800000 && file.size !== 0x1000000) throw new Error('Choose a supported 8 MiB or 16 MiB USA or European ROM.');
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (ticket !== generation) return;
    const result = await patchRom(bytes,style);
    if (ticket !== generation) return;
    previewBase.value = result.preview;
    previewBase.disabled = true;
    updatePreviews();
    previewNote.textContent = 'Previews show the selected base palette, using the USA English battle. Screenshots use the default blue window color.';
    details.textContent = result.label + '\nSelected look: ' + STYLES[style] + '\nSHA-256: ' + result.sha256;
    if (result.already) { status.textContent = 'This ROM already uses the selected look.'; return; }
    prepared = {bytes:result.bytes, filename:downloadName(file.name,style), generation:ticket};
    status.textContent = 'Ready to download — ' + STYLES[style] + '.';
    downloadButton.disabled = false;
  } catch (error) {
    if (ticket !== generation) return;
    status.textContent = error instanceof Error ? error.message : String(error);
  }
}
fileInput.addEventListener('change',prepare);
for (const radio of radios) radio.addEventListener('change',() => { if (radio.checked) return prepare(); });
previewBase.addEventListener('change',updatePreviews);
updatePreviews();
downloadButton.addEventListener('click',() => {
  if (downloadButton.disabled || !prepared || prepared.generation !== generation) return;
  const url = URL.createObjectURL(new Blob([prepared.bytes],{type:'application/octet-stream'}));
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = prepared.filename;
  document.body.appendChild(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url),10000);
});
