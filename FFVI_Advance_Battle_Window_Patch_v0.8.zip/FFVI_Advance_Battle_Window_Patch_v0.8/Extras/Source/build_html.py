#!/usr/bin/env python3
"""Build the self-contained offline HTML from the adjacent source and PNG previews."""
from pathlib import Path
import base64
import json

HERE = Path(__file__).resolve().parent
previews = {}
for base in ('original', 'restoration'):
    previews[base] = {}
    for style in ('original', 'battle', 'dialogue', 'flat', 'snes'):
        png = (HERE / 'previews' / f'{base}_{style}.png').read_bytes()
        previews[base][style] = 'data:image/png;base64,' + base64.b64encode(png).decode()
js = (HERE / 'patcher.template.js').read_text()
for key, value in [('__PROFILES__',json.loads((HERE/'profiles.json').read_text())), ('__REGIONS__',json.loads((HERE/'regions.json').read_text())), ('__PREVIEWS__',previews)]:
    js = js.replace(key,json.dumps(value,separators=(',',':')))
html = (HERE / 'page.template.html').read_text().replace('__SCRIPT__',js)
(HERE.parents[1] / 'Apply_Battle_Window_Patch.html').write_text(html)
print('Built',HERE.parents[1] / 'Apply_Battle_Window_Patch.html')
