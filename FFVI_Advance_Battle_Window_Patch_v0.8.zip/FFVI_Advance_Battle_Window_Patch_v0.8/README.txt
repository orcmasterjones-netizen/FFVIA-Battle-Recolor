FINAL FANTASY VI ADVANCE — BATTLE WINDOW PATCH v0.8
USA and Europe

Extract the ZIP and open Apply_Battle_Window_Patch.html. Choose a look,
select your ROM and download the result. The patcher works offline.
Choose “SNES-style blue range” for the lavender-to-navy gradient.
Version 0.8 fixes the battle timing differences observed in v0.7.

WINDOW STYLES

Original battle windows restores the cartridge's original boost and shading.
Dialogue colors + battle gradient removes the fixed +8 boost and retains
the original battle gradient. This is the default selection.
SNES-style blue range removes the fixed boost and shades the lower windows
from lavender blue to deep navy. The default blue fill is calibrated at
each scanline. A custom fill color uses the v0.6 light-to-dark shading.
Dialogue-style windows uses the unboosted palette and dialogue-style shading.
No gradient uses the unboosted palette and flat battle-window backgrounds.

Screenshots/FFVI_Advance_v0.8_SNES_Window_Comparison.png shows the revised
color range, the previous release and the player's original SNES reference.
The ROM supplies the interface, frame graphics and typeface.

COMPATIBILITY

Original USA       BZ6E     8 MiB    CRC32 D708F5AB
Original Europe    BZ6P    16 MiB    CRC32 D15DEBA5

All five styles support both cartridges and Novalia Spirit's regional Color
Restoration v1.01 patches. For Color Restoration, apply its matching USA or
European main patch first, followed by your preferred Animation, Lightning
and Monster supplements. Then open that ROM in the window patcher. All eight
combinations per region are recognized. Color Restoration is a separate patch.

The tool recognizes v0.7 builds for both regions and the earlier USA releases.
To upgrade a v0.7 SNES-style ROM, open it and select “SNES-style blue range.”
“Original battle windows” restores the exact base file for the detected region
and Color Restoration combination. The tool verifies source and target hashes.

USA output is 8 MiB for Original, Dialogue colors + battle gradient, or No
gradient. Dialogue-style and SNES-style outputs use 16 MiB. All European
outputs stay at 16 MiB and retain the cartridge's five language choices.

ALTERNATE PATCHING METHODS

Patches/Original_GBA and Patches/Color_Restoration_Main contain BPS files for
the clean USA game and USA Color Restoration main-only. The matching European
folders start with Europe_. Apply one BPS to its stated source. Use the HTML
or Python patcher for supplements, previously patched games and restoration.

The Python 3 command-line patcher takes the same input and produces the same
output as the HTML. Keep regions.json and profiles.json beside the script.

  python3 Extras/Source/apply_window_style.py input.gba output.gba --style snes

Style names are original, battle, snes, dialogue and flat.
Keep a copy of your battery save. Boot the new ROM normally and load an in-game
save. An emulator save state can restore the previous version's rendering code.

Credits
Color Restoration v1.01 by Novalia Spirit.
Gameplay captures from mGBA. The supplied SNES reference was already scaled.
See Extras/Verification for the measured color fit and emulator checks.
