FFVI ADVANCE - BATTLE WINDOW SHADING v0.2

Gives battle windows darker colors and shading like the dialogue boxes.
For the USA version of Final Fantasy VI Advance (BZ6E).

ORIGINAL GAME
Apply Original_GBA/Battle_Window_Shading_v0.2.bps to a clean USA ROM
using a patcher that supports BPS.

WITH COLOR RESTORATION
First apply Novalia Spirit's Color Restoration v1.01 and any of its optional
Animation, Lightning or Monster patches. Then open
Color_Restoration/Add_Window_Shading.html in your browser, choose that ROM,
and download the finished version. All eight combinations are supported.
The tool works locally on your computer.

SAVES
Keep a backup of your save. Start the updated ROM normally and load your
in-game save; avoid resuming an old emulator save state.

NOTES
v0.2 fixes a brief gray flash when entering battle and improves fading.
Tested in mGBA; other hacks and physical hardware have not been fully tested.
Color Restoration is by Novalia Spirit and must be obtained separately.
This download contains patches only, with no game ROMs.

Screenshots are in Screenshots. Source, alternate patching instructions and
test details are in Extras.
