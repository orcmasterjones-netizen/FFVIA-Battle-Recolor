# Final v0.2 theme and custom-black followup

All focused followups passed.

- **Eight native patterns, two bases:** Config, field dialogue and settled battle images are pixel-identical to v0.1 for every pattern in vanilla and Color Restoration: 48 whole-frame comparisons, zero changed pixels.
- **Eight restoration combinations:** each v0.2 build enters battle normally and produces a settled image identical to its v0.1 counterpart. Both formerly defective black-transition frames are fully black in all eight builds: 16 checked frames, zero residue.
- **Natural custom-black backgrounds, both bases:** actual Config inputs set the two pane shades F and G to RGB 0/0/0. No synthetic guest-memory edits were used. Settled v0.2 images remain identical to v0.1. Native brightness is 15; both display-buffer heads retain BLDCNT 0x84 and BLDY 4. Empty-pane samples descend through gray 47, 31, 15 and 0, confirming that black still receives the intended brighten-to-darken gradient.
- **Custom-black fades:** every entry frame was recorded. v0.2 removes the two residual gray-strip frames seen in v0.1 and never adds visible pixels to a frame that was already black.

The native brightness byte can switch to its black value just after the last dim framebuffer has been rendered. That ordinary timing occurs identically in both releases. The checks therefore use the captured image to establish blackness and document the post-frame register alignment instead of assuming every level-0 register sample describes the preceding framebuffer.

`validation-manifest.json` summarizes the results; details and screenshots are in `themes-*`, `variants-report.json`, and `custom-black/`. These checks supplement the earlier every-frame audit. They use one mGBA software renderer and inherited natural prebattle fixtures; they do not constitute hardware validation or a complete game playthrough.
