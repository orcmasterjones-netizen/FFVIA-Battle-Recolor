# FFVI Advance battle windows v0.2 — independent code audit

Reviewed November 12, 2026. Result: **PASS for the reviewed US ROM builds and the helper's tested control paths.** This is a code and instruction-level audit; the separate fresh-boot visual regressions supply gameplay evidence. It is not a proof covering every possible game scene or physical GBA hardware.

## Reviewed artifacts

- `video_audit/source/build_v02.py`, `fade_hook.s`, `v02_patch_spec.json`
- `video_audit/build/v02/disassembly.txt` and the actual emitted ROM/helper bytes
- All nine output SHA-256 hashes match `video_audit/build/v02/variants.json`.
- Standalone target: `e6d85d6d0790b9ec5ce611360d03ab3b75d0d630139aa2fb9e8e3fc118bb2817`
- Color Restoration main target: `9788ecc73b0f5e0b1120e65f67fee89d3e96ff07e491475784da66bbdff966b1`

The original v0.1 initialization hook and removal of the palette's +8/channel adjustment remain unchanged. The new helper corrects the independently observed v0.1 problem in which positive hardware brightness could lift a faded black window palette into gray. At full native brightness it preserves the v0.1 window curve.

## Hook and control flow

The new BL at `081389C0` replaces the battle-only `cmp r2,#15; beq` pair. The native scene test at `081389BE` still bypasses the hook for nonbattle scenes. Native code has already normalized the current brightness register into `r2 = 0..15`; bit 7 forces zero, otherwise the low nibble is used. This is the actual upload brightness, including the pause reduction, rather than an earlier untranslated brightness value.

The near veneer at `08146624` loads `08800101` and branches in Thumb state. The original initialization path unconditionally skips this reused padding. The helper begins at `08800100`; it does not overlap the 122-byte initialization hook at `08800000`.

For levels 0–14 the helper returns through LR to `081389C4`, the original faded-palette path. At level 15 it branches to `081389EC`, the original full-palette path. The outer upload routine saved its caller's LR before the inserted BL, so the temporary change to LR is safe.

`r2`, `r4`–`r12`, and SP are preserved. `r0`, `r1`, and `r3` are scratch at this insertion point; the original continuation initializes what it needs. The helper saves 16 bytes on the existing stack, restores SP, and allocates no persistent RAM. Condition flags are not live across the selected continuations.

## Lookup and writes

The lookup at `0880016C` contains 16 rows of 20 bytes. For normalized level `L` and index `i`, it supplies `floor(((20-i)//5) * L / 15)`. Its index `20*L+i` is bounded to 0–319, ending at `088002AB`.

The helper reads both existing display-table pointers at `03002FC0` and `03002FC4`. In each table it visits only entries 119–138, starting at `table + 119*24 + 16`. It changes only the BLDY halfword at entry offset +4, and only if that entry's mode is exactly `0084` (BG2 brighten). Runtime table bases are `03005000` and `03005F00`, giving write ranges `03005B3C`–`03005D04` and `03006A3C`–`03006C04`, at 24-byte intervals.

It does not write BLDCNT, BLDALPHA, the darkening half of the window, earlier battlefield rows, palettes, tilemaps, sprites, or gameplay variables. At native level zero all positive coefficients become zero. At level 15 the complete original v0.1 positive curve is restored. The full-bright fast path relies on both window heads retaining mode `0084` and coefficient 4; the reviewed native battle effect writers exclude these lower-window entries.

## Instruction compatibility

All reachable instructions are ARM7TDMI Thumb-1 forms, including the classic two-halfword BL. Keystone emitted `BF00` alignment padding at the veneer and after the helper's final BX. Those bytes are unreachable: control branches away or the initialization path skips them. Literal pools and lookup bytes are not executed. No reachable Thumb-2 instruction was found.

## Independent execution checks

`check_v02_helper.py` and `v02-helper-check.json` exercise the emitted helper from the native call site using an existing battle CPU state. These are synthetic instruction-level checks, not a substitute for a fresh gameplay replay.

All 16 native brightness levels passed, plus a separate full-curve restoration test. Intentionally substituted nonwindow modes were preserved. The full IWRAM comparison found only expected BLDY halfword changes and the 16-byte temporary stack save area. Every tested path preserved `r2`, `r4`–`r12`, and SP, and reached the correct original continuation.

## Measured overhead

`measure_v02_hook.py` and `v02-hook-timing.json` compare v0.1 and v0.2 from the same saved CPU state, immediately before the replaced branch pair through the common original continuation. Clock measurement uses mGBA's serialized global cycle count plus CPU cycles since the last event. WAITCNT was `4497` and the start scanline was 161.

| Upload case | Original branch cycles | v0.2 cycles | Added cycles |
| --- | ---: | ---: | ---: |
| Level 15, curve already full | 10 | 126 | 116 |
| Level 0 | 4 | 911 | 907 |
| Level 7 | 4 | 911 | 907 |
| Level 14 | 4 | 911 | 907 |
| Level 15, restoring curve from zero | 10 | 946 | 936 |

These are emulator measurements per call under the stated conditions, not a physical-hardware measurement or a universal worst-case bound. v0.2 adds a small check to each battle palette upload, with the longer loop during reduced brightness or curve restoration. It does not introduce per-scanline CPU execution; the existing hardware DMA consumes the updated tables. Documentation describing all added CPU work as initialization-only must be updated for v0.2.

## Scope and remaining limits

The intended visual change includes lower battle windows and the top action announcement box, which shares the affected palette bank. Palette banks and background layers are not permanently exclusive to those graphics in the whole game. The scene guard, constructor scope, per-entry mode guard, and separately recorded runtime tests support the limited intended scope; they do not justify claiming that every untested effect or third-party hack is guaranteed unaffected.

Release evidence should include the fresh-init battle-entry fade regression, battle exit, pause, and spell-effect comparisons for both standalone and Color Restoration builds. The v0.1 gray-lift finding is superseded only by those v0.2 runtime results, not merely by this code audit.
