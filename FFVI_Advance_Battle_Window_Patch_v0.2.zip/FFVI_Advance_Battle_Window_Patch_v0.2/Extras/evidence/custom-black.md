# Natural custom-black window and fade check

**Pass for both vanilla and Color Restoration:** a deliberately black custom window background retains the intended gradient at full brightness in v0.2. It is not mistaken for a fade.

The test used actual Config input, with no guest-memory writes or synthetic palette edits. Window Colors slot F was changed from RGB 6/6/17 to 0/0/0, and slot G from 5/5/16 to 0/0/0. Slot G supplies the main visible pane background; changing F alone does not make that large area black. The settings were confirmed with A, then normal movement entered the second Narshe battle. The same starting fixture and input sequence was used for v0.1 and v0.2 on both bases.

At settled brightness, both bases show:

- Native brightness level **15**.
- Both display buffers' entry 119: **BLDCNT 0x84, BLDY 4**.
- Empty background at x80: RGB **47/47/47** at y124, **31/31/31** at y129, **15/15/15** at y134, and **0/0/0** at y139 and below.
- **Zero changed pixels** between the corresponding v0.1 and v0.2 settled screenshots.

Every one of the 354 battle-entry frames was recorded for each of the four runs, giving 708 paired entry frames. All fully black v0.1 frames remain fully black in v0.2. At entry indices 226–227, v0.1 has 3,602 residual nonblack pixels with maximum channel value 63; v0.2 is fully black with zero nonblack pixels. This result is identical for vanilla and restoration.

One timing detail is recorded explicitly: after frame index 160, the brightness byte already reads `0x80` (normalized level zero), but the captured image is the final uniformly dim transition frame, identical in both versions. Its maximum RGB value is 24 for vanilla and 8 for restoration. The actual all-black hold spans indices 161–225. A post-frame register read therefore must not be treated as the complete brightness state used for that frame's earlier visible scanout. This native transition is not a new v0.2 artifact.

`run_custom_black.py` reproduces the natural setup and entry. The definitive runs are `vanilla_v01`, `vanilla_v02`, `restoration_v01`, and `restoration_v02`; earlier top-level editor images and the short `v01`/`v02` folders are exploratory F-only probes, not the final black-background fixture. Each definitive directory contains the editor/config/prebattle/settled states, representative screenshots, per-frame RGB hashes and brightness statistics, and ROM hash. `comparison.json` contains exact results; `validation-manifest.json` summarizes them.

This remains one mGBA/HLE BIOS test with an inherited Config fixture followed by normal battle initialization. It is not a hardware or second-emulator result.
