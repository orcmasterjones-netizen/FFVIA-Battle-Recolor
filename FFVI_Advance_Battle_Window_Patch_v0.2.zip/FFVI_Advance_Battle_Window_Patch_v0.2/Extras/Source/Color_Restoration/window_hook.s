; Thumb-1 / ARM7TDMI. Assemble at 0x08800000.
; Valid r4 range: 119..159, inherited from the original 41-iteration loop.
; Entry SP remains the original routine frame; no push/pop is performed.
; r3,r4,r6-r12,SP preserved; r5 restored to 0xC4; r0-r2 are scratch.
; Each table halfword: low byte BLDCNT, high byte BLDY.

movs r0, r4
subs r0, #119
lsls r0, r0, #1
adr r1, table
ldrh r5, [r1, r0]
ldr r0, [sp, #4]
lsls r1, r0, #1
ldr r0, [sp, #16]
adds r2, r1, r0
ldr r0, [sp, #20]
adds r1, r1, r0
lsls r0, r5, #24
lsrs r0, r0, #24
strh r0, [r2]
strh r0, [r1]
lsrs r0, r5, #8
strh r0, [r2, #4]
strh r0, [r1, #4]
movs r5, #196
bx lr
.balign 4
table:

.hword 0x0484
.hword 0x0384
.hword 0x0384
.hword 0x0384
.hword 0x0384
.hword 0x0384
.hword 0x0284
.hword 0x0284
.hword 0x0284
.hword 0x0284
.hword 0x0284
.hword 0x0184
.hword 0x0184
.hword 0x0184
.hword 0x0184
.hword 0x0184
.hword 0x0084
.hword 0x0084
.hword 0x0084
.hword 0x0084
.hword 0x00c4
.hword 0x00c4
.hword 0x00c4
.hword 0x00c4
.hword 0x00c4
.hword 0x01c4
.hword 0x01c4
.hword 0x01c4
.hword 0x01c4
.hword 0x01c4
.hword 0x02c4
.hword 0x02c4
.hword 0x02c4
.hword 0x02c4
.hword 0x02c4
.hword 0x03c4
.hword 0x03c4
.hword 0x03c4
.hword 0x03c4
.hword 0x03c4
.hword 0x04c4
