; Thumb-1, ARM7TDMI. Assemble at08800100.
; r2 is native battle fade level0..15; do not allocate new WRAM.

push {r4, r5, r6, r7}
ldr r0, table_pointers
ldr r4, [r0]
ldr r5, [r0, #4]
ldr r1, window_offset
adds r4, r4, r1
adds r5, r5, r1
cmp r2, #15
bne update
ldrh r0, [r4]
cmp r0, #132
bne update
ldrh r0, [r5]
cmp r0, #132
bne update
ldrh r0, [r4, #4]
cmp r0, #4
bne update
ldrh r0, [r5, #4]
cmp r0, #4
beq finish
update:
lsls r3, r2, #2
adds r3, r3, r2
lsls r3, r3, #2
adr r7, curve
adds r7, r7, r3
movs r6, #20
loop:
ldrb r3, [r7]
ldrh r0, [r4]
cmp r0, #132
bne next_a
strh r3, [r4, #4]
next_a:
ldrh r0, [r5]
cmp r0, #132
bne next_b
strh r3, [r5, #4]
next_b:
adds r4, #24
adds r5, #24
adds r7, #1
subs r6, #1
bne loop
finish:
pop {r4, r5, r6, r7}
cmp r2, #15
beq full_brightness
bx lr
full_brightness:
ldr r0, full_path
bx r0
.balign 4
table_pointers: .word 0x03002fc0
window_offset: .word 2872
full_path: .word 0x081389ed
curve:

.byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0
.byte 2,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0
.byte 2,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0
.byte 2,2,2,2,2,2,1,1,1,1,1,0,0,0,0,0,0,0,0,0
.byte 2,2,2,2,2,2,1,1,1,1,1,0,0,0,0,0,0,0,0,0
.byte 3,2,2,2,2,2,1,1,1,1,1,0,0,0,0,0,0,0,0,0
.byte 3,2,2,2,2,2,1,1,1,1,1,0,0,0,0,0,0,0,0,0
.byte 3,2,2,2,2,2,1,1,1,1,1,0,0,0,0,0,0,0,0,0
.byte 4,3,3,3,3,3,2,2,2,2,2,1,1,1,1,1,0,0,0,0
