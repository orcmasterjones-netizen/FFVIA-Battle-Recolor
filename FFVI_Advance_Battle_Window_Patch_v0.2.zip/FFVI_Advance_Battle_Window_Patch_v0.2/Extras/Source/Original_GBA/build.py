#!/usr/bin/env python3
"""Apply USA FFVI Advance battle-window shading to v0.2.
Uses only the Python standard library. Exact input and output hashes enforced.
Usage: python3 build.py input.gba output.gba
"""
from pathlib import Path
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
VARIANTS=json.loads((HERE/'variants.json').read_text())
SPEC=json.loads((HERE/'patch_spec.json').read_text())
def apply(source):
    digest=hashlib.sha256(source).hexdigest()
    if any(digest==v['target_sha256'] for v in VARIANTS.values()):
        raise ValueError('This ROM already has window shading v0.2. No update is needed.')
    match=next(((name,v) for name,v in VARIANTS.items() if digest in (v['source_sha256'],v['v01_sha256'])),None)
    if match is None:
        raise ValueError('Unrecognized ROM. Use a supported USA source ROM for this patch; see README.txt.')
    name,v=match;upgrade=digest==v['v01_sha256']
    if len(source)!=(v['v01_size'] if upgrade else v['source_size']):
        raise ValueError('Unexpected input size.')
    out=bytearray([SPEC['fill']])*SPEC['size'];out[:len(source)]=source
    for segment in SPEC['segments']:
        data=bytes.fromhex(segment['data']);at=segment['offset'];out[at:at+len(data)]=data
    if hashlib.sha256(out).hexdigest()!=v['target_sha256']:
        raise ValueError('Output verification failed.')
    return bytes(out), v['label'], 'applied v0.2'
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: python3 build.py input.gba output.gba')
    src,dst=map(Path,sys.argv[1:])
    if src.resolve()==dst.resolve() or dst.exists():
        raise SystemExit('Choose a new output filename; existing files are not overwritten.')
    result,label,mode=apply(src.read_bytes());dst.write_bytes(result)
    print('Created',dst,'—',label,'—',mode)
